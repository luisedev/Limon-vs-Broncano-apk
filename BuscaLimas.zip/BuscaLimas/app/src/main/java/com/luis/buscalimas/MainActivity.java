package com.luis.buscalimas;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.Point;
import android.os.Bundle;
import android.view.Display;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;


import androidx.appcompat.app.AppCompatActivity;
import androidx.gridlayout.widget.GridLayout;

import org.w3c.dom.Text;

public class MainActivity extends AppCompatActivity {
    private static final int OPCION = 0;
    //Implementar función explotar al descubrir limon
    /* En esta funcion al descubrir un limon el programa comprobará los botones colindantes
     *  si tienen un limon será revelado y explotará, sino quitaremos 1/3 vidas al jugador
     *   si el jugador pierde las 3 vidas, pierde
     */
    GridLayout grid;
    Button reset;
    ImageView cor;
    int numeroColumnas = 5;
    int numeroFilas = 5;
    int contador;
    boolean enabled;
    //Ajuste de probabilidad de aparicion de limones
    /* Siendo 1 el mas pequeño y 10 la mas grande
     *  El usuario lo podrá ajustar en el juego
     * */
    int probabilidad = 5;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        inicializarVariables();
        enabled = true;
        partida();
    }

    private void inicializarVariables() {
        cor = findViewById(R.id.imageViewCorazones);
        cor.setImageResource(R.drawable.broncano);
        reset = findViewById(R.id.reset);
        reset.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                resetGrid();
            }
        });
    }

    private void resetGrid() {
        enabled = true;
        contador = 0;
        grid = null;
        grid = findViewById(R.id.miGrid);
        grid.removeAllViewsInLayout();
        partida();
    }

    private void partida() {
        TextView punt = findViewById(R.id.textViewPuntuacion);
        punt.setText("0");
        rellenaGrid();
    }

    private void rellenaGrid() {
        cor.setImageDrawable(getDrawable(R.drawable.trescor));
        grid = null;
        grid = findViewById(R.id.miGrid);
        grid.setRowCount(numeroFilas);
        grid.setColumnCount(numeroColumnas);
        Button b;
        for (int i = 0; i < numeroColumnas * numeroFilas; i++) {
            b = rellenaBoton();
            grid.addView(b, i);
        }

    }

    private Button rellenaBoton() {
        final boolean tiene;
        final boolean tieneLimon;
        int limon = (int) Math.floor(Math.random() * 10 + 1);
        int limon2 = (int) Math.floor(Math.random() * 10 + 1);

        //Parametros del boton
        Button b = new Button(this);
        Display display = getWindowManager().getDefaultDisplay();
        Point size = new Point();
        display.getSize(size);
        int ancho = size.x;
        int alto = size.y;

        b.setLayoutParams(new ViewGroup.LayoutParams(ancho / numeroColumnas, alto / (numeroFilas) - 80));
        b.setBackground(getDrawable(R.drawable.suelo));
        b.setId(View.generateViewId());

        //Probabilidad de aparición de limones
        if (limon < probabilidad) {
            tiene = true;
            tieneLimon = false;
        } else if (limon2 < probabilidad) {
            tiene = false;
            tieneLimon = true;
        } else {
            tiene = false;
            tieneLimon = false;
        }

        //Al clicar..
        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (enabled) {
                    if (tiene) {
                        Button b = (Button) v;
                        contador++;
                        v.setBackground(getDrawable(R.drawable.broncano));
                        v.animate().rotationX(10);
                        compruebaContador();
                    } else if (tieneLimon) {
                        Button b = (Button) v;
                        v.setBackground(getDrawable(R.drawable.limon));
                        compruebaContadorLimones();
                    } else {
                        Button b = (Button) v;
                        v.setBackground(getDrawable(R.drawable.pisado));
                    }
                } else {
                    Toast.makeText(MainActivity.this, "Pulsa el botón de reset para reiniciar la partida", Toast.LENGTH_SHORT).show();
                }
            }
        });
        return b;
    }

    private void compruebaContadorLimones() {
        TextView punt = findViewById(R.id.textViewPuntuacion);
        int puntuacion = Integer.parseInt(punt.getText().toString());
        puntuacion++;
        if (puntuacion >= 3) {
            Toast.makeText(this, "ENHORABUENA, HAS GANADO!", Toast.LENGTH_SHORT).show();
            enabled = false;
            // resetGrid();
        }
        punt.setText(String.valueOf(puntuacion));

    }

    private void compruebaContador() {
        ImageView cor = findViewById(R.id.imageViewCorazones);
        if (contador == 1) {
            cor.setImageDrawable(getDrawable(R.drawable.doscor));
        } else if (contador == 2) {
            cor.setImageDrawable(getDrawable(R.drawable.cor));
        } else if (contador == 3) {
            enabled = false;
            Toast.makeText(this, "Has perdido, pulsa reset", Toast.LENGTH_SHORT).show();

            contador = 0;
            //resetGrid();

        }
    }
}
